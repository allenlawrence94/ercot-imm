var searchData=
[
  ['is_5fsoluion',['is_soluion',['../Problem_8h.html#a62a006f2e879b92deea23e5d6358c2ba',1,'Problem.h']]]
];
