var searchData=
[
  ['var_5fname_5flength',['VAR_NAME_LENGTH',['../Var_8h.html#a54e065a24ebe664424713436fd03f49a',1,'Var.h']]],
  ['vararr_5fname_5flength',['VARARR_NAME_LENGTH',['../Var_8h.html#a4c2c67fcc52e812ae5c11fa6c8a711a7',1,'Var.h']]]
];
