var searchData=
[
  ['using_20mipcl_20in_20gui_20applications',['Using MIPCL in GUI applications',['../../../../mipcl/docs/html/MIPCLmsgs.html',1,'']]],
  ['using_20mipcl_20with_20miplib2010_20test_20engine',['Using MIPCL with MIPLIB2010 test engine',['../../../../mipcl/docs/html/miplibEngine.html',1,'']]]
];
