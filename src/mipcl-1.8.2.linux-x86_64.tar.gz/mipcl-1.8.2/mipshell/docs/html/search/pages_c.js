var searchData=
[
  ['yield_20management',['Yield management',['../yieldManagement.html',1,'']]]
];
