var searchData=
[
  ['set_5fmax_5fit_5fnum',['SET_MAX_IT_NUM',['../Set_8h.html#a889b341c2f6b0b83b75f472b918ed9e8',1,'Set.h']]],
  ['setcutpattern',['setcutpattern',['../Problem_8h.html#a106cf357a811aaf73b050cb6ebdeaf08',1,'setcutpattern():&#160;Problem.h'],['../Problem_8h.html#a106cf357a811aaf73b050cb6ebdeaf08',1,'setcutpattern():&#160;Problem.h']]]
];
