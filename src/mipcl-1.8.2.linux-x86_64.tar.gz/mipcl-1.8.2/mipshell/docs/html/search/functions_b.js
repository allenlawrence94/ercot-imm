var searchData=
[
  ['newdvar',['newDvar',['../classCDvar.html#ae4bea045b8a279d94a2fb4777820ec3b',1,'CDvar::newDvar(CVar &amp;var, const char *values)'],['../classCDvar.html#a25a0a0aee7e3489b6d8f95394b1c4ad9',1,'CDvar::newDvar(CVar &amp;var, CSet&lt; double &gt; &amp;values)']]]
];
