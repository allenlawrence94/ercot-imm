var searchData=
[
  ['electricity_20generation_20planning',['Electricity Generation Planning',['../electrGenPlan.html',1,'']]]
];
