var searchData=
[
  ['function',['function',['../classCProblem.html#afbe84b1bb34aaf874f2be603113b7c7f',1,'CProblem::function(CVar &amp;x, const char *points)'],['../classCProblem.html#a32bfb1fe1f26ddf68e372693e1e0fc52',1,'CProblem::function(CVar &amp;x, std::string &amp;points)']]]
];
