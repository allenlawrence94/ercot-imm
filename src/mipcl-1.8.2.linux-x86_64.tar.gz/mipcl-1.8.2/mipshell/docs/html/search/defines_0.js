var searchData=
[
  ['ctr_5fname_5flength',['CTR_NAME_LENGTH',['../Ctr_8h.html#aea10f844c503a02c6542d11977989298',1,'Ctr.h']]]
];
