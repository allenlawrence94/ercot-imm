var searchData=
[
  ['cvarptr',['CVarPtr',['../VarArray_8h.html#ada23d2afd72af996dc886628882be3be',1,'VarArray.h']]]
];
