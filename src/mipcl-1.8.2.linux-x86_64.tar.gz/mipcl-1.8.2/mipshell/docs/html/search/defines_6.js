var searchData=
[
  ['preprocoff',['preprocoff',['../Problem_8h.html#a519b31597e2dfd997c765bd173d3c08b',1,'Problem.h']]],
  ['printmatrix',['printmatrix',['../Problem_8h.html#ac431af149b022e7c848509c136d4baf6',1,'Problem.h']]],
  ['printsol',['printsol',['../Problem_8h.html#a71d33b1bbfc010c85e7d36ab2fe3f058',1,'Problem.h']]]
];
