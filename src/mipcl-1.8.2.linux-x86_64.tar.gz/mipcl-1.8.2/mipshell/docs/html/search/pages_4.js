var searchData=
[
  ['generalized_20assignment_20problem',['Generalized assignment problem',['../../../../mipcl/docs/html/gap.html',1,'']]]
];
