var searchData=
[
  ['traveling_20salesman_20problem',['Traveling salesman problem',['../../../../mipcl/docs/html/tsp.html',1,'']]]
];
