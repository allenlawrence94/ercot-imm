var searchData=
[
  ['dispose',['dispose',['../classby_1_1bsu_1_1JVmipcl_1_1LP.html#a2f39868890b4df8644a65d21de3f3e20',1,'by.bsu.JVmipcl.LP.dispose()'],['../classby_1_1bsu_1_1JVmipcl_1_1MIP.html#ab4fa7aaf9daa4e18dd86c541a148bf37',1,'by.bsu.JVmipcl.MIP.dispose()']]]
];
