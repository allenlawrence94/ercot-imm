var searchData=
[
  ['var',['Var',['../classby_1_1bsu_1_1JVmipshell_1_1Var.html#a5b0c98c882adb8ea40f9e67e4eb2ec5b',1,'by.bsu.JVmipshell.Var.Var(LPshell prob, String name, int type, double lb, double ub)'],['../classby_1_1bsu_1_1JVmipshell_1_1Var.html#ab03c958d6d716389eb661709fa74e097',1,'by.bsu.JVmipshell.Var.Var(LPshell prob, String name, int type)']]],
  ['varvector',['VarVector',['../classby_1_1bsu_1_1JVmipshell_1_1VarVector.html#aaaacefcec063245fcbbbe1d3cf890ccc',1,'by.bsu.JVmipshell.VarVector.VarVector(LPshell prob, String name, int type, double lb, double ub, int... sizes)'],['../classby_1_1bsu_1_1JVmipshell_1_1VarVector.html#ad48c4ca3d180cf5e525402e56d510921',1,'by.bsu.JVmipshell.VarVector.VarVector(LPshell prob, String name, int type, int... sizes)']]]
];
