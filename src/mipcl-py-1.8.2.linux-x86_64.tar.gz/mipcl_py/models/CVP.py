from mipcl_py.mipshell.mipshell import *

class CVP(Problem):
        """Closest Vector Problem (CVP)

        CVP is the problem of finding in a lattice vector that is closes to a given vector.

        Attributes:
            v (float array): m-vector;
            x (list of Var): vextor of *n* integer variables;
            y (list of Var): vextor of *m* real variables;
            t (Var): real variable.
  
        """

    def model(self,B,v):
         """Builds a **MIPCL-PY** model for the CVP: min{||*v-Bx*||: *x* is integer vector}.

        Args:
            B (float 2-dimensional list): mxn-matrix;
            v (float list): m-vector.

        """
        self.v = v
        m, n = len(v),  len(B[0])
        self.x = x = VarVector((n,),"x",INT,lb=-VAR_INF)
        self.y = y = VarVector((m,),"y",lb=-VAR_INF)
        self.t = t = Var("t")

        minimize(t)
        for i in range(m):
            sum_(B[i][j]*x[j] for j in range(n)) + y[i] == v[i]
        norm(y) <= t

    def printSolution(self):
        t, x, y, v = self.t, self.x, self.y, self.v
        m, n = len(y), len(x)

        print('Minimum distance = {:.4f}\n'.format(t.val))
        str = 'x = ({:d}'.format(int(x[0].val + 0.5))
        for j in range(1,n):
            str+=', {:d}'.format(int(x[j].val + 0.5))
        print(str+')\n')

        print(' _____________________________________')
        print('|         v        |         Bx       |')
        print('|------------------+------------------|')
        for i in range(m):
            print('| {:16.4f} | {:16.4f} |'.format(v[i],v[i]-y[i].val))
        print(' -------------------------------------')

