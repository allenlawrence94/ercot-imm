"""A library of Python classes for solving optimization problems.

.. moduleauthor:: Nicolai N. Pisaruk <nicolaipisaruk@gmail.com>

"""

