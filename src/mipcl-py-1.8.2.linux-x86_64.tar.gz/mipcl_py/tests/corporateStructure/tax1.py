#!/usr/bin/python

from mipcl_py.models.corporateStructuring import CorporateStructure

target = 8
Countries = (
    {
         'Name': '0',
         'taxRule': 'S', 'domesticTax': 0.46, 'foreignTax': 0.46, 'profit': 0,
         'withholdingTax': {
              1: 0.15, 2: 0.25, 3: 0.25, 4: 0.25, 5: 0.15, 6: 0.05, 7: 0.15, 8: 0.06, 9: 0.15
         }
    },
    {
         'Name': '1',
         'taxRule': 'D', 'domesticTax': 0.37, 'foreignTax': 0.37, 'profit': 117,
         'withholdingTax': {
              0: 0.15, 2: 0.32, 3: 0.32, 4: 0.32, 5: 0.15, 6: 0.00, 7: 0.00, 8: 0.05, 9: 0.00
         }
    },
    {
         'Name': '2',
         'taxRule': 'D', 'domesticTax': 0.25, 'foreignTax': 0.25, 'profit': 81,
         'withholdingTax': {
              0: 0.20, 1: 0.20, 3: 0.20, 4: 0.00, 5: 0.20, 6: 0.20, 7: 0.20, 8: 0.20, 9: 0.20
         }
    },
    {
         'Name': '3',
         'taxRule': 'D', 'domesticTax': 0.33, 'foreignTax': 0.33, 'profit': 36,
         'withholdingTax': {
              0: 0.27, 1: 0.27, 2: 0.27, 4: 0.27, 5: 0.27, 6: 0.27, 7: 0.27, 8: 0.05, 9: 0.27
         }
    },
    {
         'Name': '4',
         'taxRule': 'D', 'domesticTax': 0.25, 'foreignTax': 0.25, 'profit': 0,
         'withholdingTax': {
              0: 0.20, 1: 0.20, 2: 0.00, 3: 0.20, 5: 0.20, 6: 0.20, 7: 0.20, 8: 0.20, 9: 0.20
         }
    },
    {
         'Name': '5',
         'taxRule': 'E', 'domesticTax': 0.35, 'foreignTax': 0.0, 'profit': 53,
         'withholdingTax': {
              0: 0.00, 1: 0.00, 2: 0.00, 3: 0.00, 4: 0.00, 6: 0.00, 7: 0.00, 8: 0.00, 9: 0.00
         }
    },
    {
         'Name': '6',
         'taxRule': 'E', 'domesticTax': 0.35, 'foreignTax': 0.0, 'profit': 102,
         'withholdingTax': {
              0: 0.06, 1: 0.00, 2: 0.25, 3: 0.25, 4: 0.25, 5: 0.00, 7: 0.00, 8: 0.05, 9: 0.00
         }
    },
    {
         'Name': '7',
         'taxRule': 'D', 'domesticTax': 0.37, 'foreignTax': 0.37, 'profit': 103,
         'withholdingTax': {
              0: 0.15, 1: 0.00, 2: 0.32, 3: 0.32, 4: 0.32, 5: 0.15, 6: 0.00, 8: 0.05, 9: 0.00
         }
    },
    {
         'Name': '8',
         'taxRule': 'W', 'domesticTax': 0.35, 'foreignTax': 0.35, 'profit': 373,
         'withholdingTax': {
              0: 0.05, 1: 0.05, 2: 0.30, 3: 0.05, 4: 0.30, 5: 0.05, 6: 0.05, 7: 0.05, 9: 0.05
         }
    },
    {
         'Name': '9',
         'taxRule': 'W', 'domesticTax': 0.4, 'foreignTax': 0.2, 'profit': 157,
         'withholdingTax': {
              0: 0.15, 1: 0.00, 2: 0.25, 3: 0.25, 4: 0.25, 5: 0.15, 6: 0.00, 7: 0.00, 8: 0.05
         }
    },
)

prob = CorporateStructure('tax1')
prob.model(target,Countries)
prob.optimize(False)
prob.printSolution()
